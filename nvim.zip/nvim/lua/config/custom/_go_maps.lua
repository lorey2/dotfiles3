-- These run Go-specific plugin commands
vim.keymap.set("n", "<leader>gr", "<cmd>GoRun<CR>", { desc = "Go [R]un" })
vim.keymap.set("n", "<leader>gt", "<cmd>GoTest<CR>", { desc = "Go [T]est" })
-- Note: <leader>cf is now handled in _lsp.lua for better reliability>", { desc = "Go [F]ormat (gofmt)" })
