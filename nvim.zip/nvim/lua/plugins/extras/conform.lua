-- I can't lie I really like conform because it formats a lot of files but I cannot in good faith enable it by default.
-- Have fun with it!
-- return {
	-- "stevearc/conform.nvim",
	-- opts = {
	-- 	format_on_save = function(bufnr)
	-- 		-- Disable "format_on_save lsp_fallback" for languages that don't
	-- 		-- have a well standardized coding style.
	-- 		local disable_filetypes = { c = true, cpp = true }
	-- 		if disable_filetypes[vim.bo[bufnr].filetype] then
	-- 			return nil
	-- 		else
	-- 			return {
	-- 				timeout_ms = 500,
	-- 				lsp_format = "fallback",
	-- 			}
	-- 		end
	-- 	end,
	-- },
-- }



return {
  "stevearc/conform.nvim",
  opts = {
    formatters_by_ft = {
      -- Assigning gofmt and goimports to Go files
      go = { "gofmt", "goimports" },
    },
    format_on_save = {
      timeout_ms = 500,
      lsp_format = "fallback",
    },
  },
}
